﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

public class WorkTrackSetting
{
    [Key]
    public Guid Id { get; set; }

    [ForeignKey("WorkTimeSetting")]
    public Guid? WorkTimeId { get; set; }
    public WorkTimeSetting WorkTimeSetting { get; set; }

    [ForeignKey("WorkDateSetting")]
    public Guid? WorkDateId { get; set; }
    public WorkDateSetting WorkDateSetting { get; set; }

    [ForeignKey("WorkPermissionSetting")]
    public Guid? WorkPermissionId { get; set; }
    public WorkPermissionSetting WorkPermissionSetting { get; set; }

    [ForeignKey("RiskPerfomanceSetting")]
    public Guid? RiskPerfomanceId { get; set; }
    public RiskPerformanceSetting RiskPerfomanceSetting { get; set; }
    public bool IsDeleted { get; set; } = false;  // Soft delete flag
}
