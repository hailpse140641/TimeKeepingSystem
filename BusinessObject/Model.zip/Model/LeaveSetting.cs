﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

public class LeaveSetting
{
    [Key]
    public Guid LeaveSettingId { get; set; }

    [ForeignKey("Department")]
    public Guid DepartmentId { get; set; }
    public Department Department { get; set; }

    [Required]
    public bool IsManagerAssigned { get; set; }
    public bool IsDeleted { get; set; } = false;  // Soft delete flag
}

