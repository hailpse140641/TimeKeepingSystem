﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

public class RequestWorkTime
{
    [Key]
    public Guid Id { get; set; }

    [Required]
    [StringLength(50)]
    public string Name { get; set; }
    [Required]
    public DateTime RealHourStart { get; set; }
    [Required]
    public DateTime RealHourEnd { get; set; }

    public float? NumberOfComeLateHour { get; set; }
    public float? NumberOfLeaveEarlyHour { get; set; }

    [Required]
    [ForeignKey("WorkslotEmployee")]
    public Guid WorkslotEmployeeId { get; set; }
    public WorkslotEmployee WorkslotEmployee { get; set; }
    public bool IsDeleted { get; set; } = false;  // Soft delete flag

}
