using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

public class UserAccount
{
    [Key]
    public int ID { get; set; }

    [Required]
    [StringLength(50)]
    public string Username { get; set; }

    [Required]
    [StringLength(50)]
    [EmailAddress]
    public string Email { get; set; }

    [Required]
    public string PasswordHash { get; set; }

    [Required]
    public bool IsActive { get; set; }

    [ForeignKey("Employee")]
    public Guid? EmployeeId { get; set; }

    [ForeignKey("RoleID")]
    public int RoleID { get; set; }
    public Role Role { get; set; }

    public virtual Employee Employee { get; set; }
    public bool IsDeleted { get; set; } = false;  // Soft delete flag
}
