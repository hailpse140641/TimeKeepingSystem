﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

public class Department
{
    [Key]
    public Guid Id { get; set; }

    [ForeignKey("Employee")]
    public Guid ManagerId { get; set; }
    public Employee Manager { get; set; }

    [ForeignKey("WorkTrackSetting")]
    public Guid WorkTrackId { get; set; }
    public WorkTrackSetting WorkTrackSetting { get; set; }
    public bool IsDeleted { get; set; } = false;  // Soft delete flag
}
