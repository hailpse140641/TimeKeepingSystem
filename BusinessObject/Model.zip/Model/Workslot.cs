﻿using System.ComponentModel.DataAnnotations;

public class Workslot
{
    [Key]
    public int Id { get; set; }

    [Required]
    public int WorkTrackId { get; set; }
    public bool IsDeleted { get; set; } = false;  // Soft delete flag
}
