﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

public class WorkslotEmployee
{
    [Key]
    public Guid Id { get; set; }

    [Required]
    public DateTime Date { get; set; }

    [Required]
    public DateTime CheckInTime { get; set; }

    [Required]
    public DateTime CheckOutTime { get; set; }

    [Required]
    [ForeignKey("Employee")]
    public Guid EmployeeId { get; set; }
    public Employee Employee { get; set; }

    [Required]
    [ForeignKey("Workslot")]
    public int WorkslotId { get; set; }
    public Workslot Workslot { get; set; }

    [Required]
    [ForeignKey("AttendanceStatus")]
    public Guid AttendanceStatusId { get; set; }
    public AttendanceStatus AttendanceStatus { get; set; }

    [ForeignKey("RequestLeave")]
    public Guid? RequestLeaveId { get; set; }
    public RequestLeave? RequestLeave { get; set; }

    [ForeignKey("RequestWorkTime")]
    public Guid? RequestWorkTimeId { get; set; }
    public RequestWorkTime? RequestWorkTime { get; set; }
    public bool IsDeleted { get; set; } = false;  // Soft delete flag
}
