﻿using System.ComponentModel.DataAnnotations;

public class WorkTimeSetting
{
    [Key]
    public Guid Id { get; set; }

    [Required]
    public double ExpectWorkHour { get; set; }

    [Required]
    public double MinimumProductiveWorkHour { get; set; }
    public bool IsDeleted { get; set; } = false;  // Soft delete flag
}
