﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

public class Employee
{
    [Key]
    public Guid Id { get; set; }

    [Required]
    [StringLength(50)]
    public string FirstName { get; set; }

    [Required]
    [StringLength(50)]
    public string LastName { get; set; }

    [Required]
    [StringLength(50)]
    public string Role { get; set; }

    [ForeignKey("Employee")]
    public Guid? ManagerId { get; set; }
    public Employee Manager { get; set; }

    [ForeignKey("Department")]
    public Guid DepartmentId { get; set; }
    public Department Department { get; set; }

    // Existing properties remain unchanged
    public int? UserID { get; set; } // Nullable if not all Employees will have UserAccounts
    public virtual UserAccount UserAccount { get; set; } // Navigation Property

    public bool IsDeleted { get; set; } = false;  // Soft delete flag
}
