﻿using System.ComponentModel.DataAnnotations;

public class RequestOverTime
{
    [Key]
    public Guid Id { get; set; }

    [Required]
    [StringLength(50)]
    public string Name { get; set; }
    [Required]
    public DateTime FromHour { get; set; }
    [Required]
    public float NumberOfHour { get; set; }
    [Required]
    public DateType DateType { get; set; }
    public bool IsDeleted { get; set; } = false;  // Soft delete flag
}

public enum DateType
{
    Holiday,
    NormalWorkingDate,
    Weekend
}
